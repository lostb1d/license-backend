from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(correctOption)
admin.site.register(chapter)
admin.site.register(geomaticsQuestions)
admin.site.register(weightage)


