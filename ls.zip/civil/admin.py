from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(correctOption)
admin.site.register(chapter)
admin.site.register(civilQuestions)
admin.site.register(weightage)
